# FGCU Artverse - API Documentation

## Overview
This application connects directly to the FGCU Dataverse API to fetch and display artwork metadata from the "art" collection.

## API Configuration

### Credentials
The API client is configured with the following credentials (located in `/api/dataverseClient.ts`):

- **Base URL**: `https://dataverse.fgcu.edu`
- **API Key**: `849522d9-0aef-408e-9c93-6ae6adb4847d`
- **Subtree**: `art`

### API Endpoints Used

1. **List Collection Contents**
   ```
   GET https://dataverse.fgcu.edu/api/dataverses/art/contents
   Headers: X-Dataverse-key: {API_KEY}
   ```
   Returns a list of all datasets in the "art" collection.

2. **Get Dataset Details**
   ```
   GET https://dataverse.fgcu.edu/api/datasets/{dataset_id}
   Headers: X-Dataverse-key: {API_KEY}
   ```
   Returns detailed metadata for a specific dataset/artwork.

3. **Access Dataset Files/Images**
   ```
   GET https://dataverse.fgcu.edu/api/access/datafile/{file_id}?imageThumb=400
   ```
   Returns the image file or thumbnail for display.

## How It Works

### Data Fetching Process

1. **Initial Load**: When the Gallery page loads, it calls `fetchArtworkDatasets()`
2. **Get Dataset List**: Fetches all datasets from the "art" subtree
3. **Fetch Details**: For each dataset, makes an additional API call to get full metadata
4. **Parse Metadata**: Extracts relevant fields from the Dataverse metadata structure:
   - Title
   - Artist/Author
   - Description
   - Publication Date/Year
   - Subject/Medium
   - Image files

### Metadata Extraction

The Dataverse API returns metadata in a structured format with `metadataBlocks`. The client extracts:

- **Citation fields**: Title, author, description, dates, subjects
- **File information**: Images and their access URLs
- **Publication info**: Release dates, versions

### Image Handling

- Images are accessed via the Dataverse file API
- Thumbnails are generated using the `?imageThumb=400` parameter
- Fallback UI (Palette icon) displays if no image is available

## Frontend Features

### Search Functionality
The `searchArtworks()` function filters artworks by:
- Title
- Artist name
- Description
- Medium/subject

### Error Handling
- Network errors are caught and displayed to users
- Retry functionality allows reconnection attempts
- Missing images gracefully fall back to placeholder icons

## Environment Variables (Optional)

For easier configuration in production, you can move these to environment variables:

```env
VITE_DATAVERSE_BASE_URL=https://dataverse.fgcu.edu
VITE_DATAVERSE_API_KEY=849522d9-0aef-408e-9c93-6ae6adb4847d
VITE_DATAVERSE_SUBTREE=art
```

Then update `/api/dataverseClient.ts` to use:
```typescript
const DATAVERSE_BASE_URL = import.meta.env.VITE_DATAVERSE_BASE_URL;
const API_KEY = import.meta.env.VITE_DATAVERSE_API_KEY;
const SUBTREE = import.meta.env.VITE_DATAVERSE_SUBTREE;
```

## API Rate Limits

Please be mindful of API usage. The Dataverse API may have rate limits. Consider:
- Caching responses locally
- Implementing pagination for large collections
- Adding request throttling if needed

## Troubleshooting

### CORS Issues
If you encounter CORS errors, ensure:
- The API key has proper permissions
- The Dataverse instance allows cross-origin requests

### No Artworks Displayed
- Check that the "art" subtree exists and is accessible
- Verify the API key has read permissions
- Check browser console for specific error messages

### Images Not Loading
- Some datasets may not have image files
- File permissions may restrict access
- Check that file IDs are valid in the Dataverse
