// Utility functions

// Create page URL for routing
export function createPageUrl(pageName: string): string {
  if (pageName === 'Gallery') {
    return '/';
  }
  return `/${pageName.toLowerCase()}`;
}

// Format date string
export function formatDate(dateString: string): string {
  if (!dateString) return '';
  
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  } catch {
    return dateString;
  }
}

// Truncate text to specified length
export function truncateText(text: string, maxLength: number): string {
  if (!text || text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}
