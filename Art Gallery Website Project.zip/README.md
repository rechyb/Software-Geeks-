
  # Art Gallery Website Project

  This is a code bundle for Art Gallery Website Project. The original project is available at https://www.figma.com/design/0srzGVEWPC6R0EJqnGO1Wa/Art-Gallery-Website-Project.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  