import React from "react";
import { motion } from "motion/react";
import { Card, CardContent } from "../ui/card";
import { User, Calendar, Palette } from "lucide-react";
import type { Artwork } from "../../api/dataverseClient";

interface ArtworkCardProps {
  artwork: Artwork;
  index: number;
  onClick: () => void;
}

export default function ArtworkCard({ artwork, index, onClick }: ArtworkCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
      whileHover={{ y: -8 }}
      onClick={onClick}
      className="cursor-pointer"
    >
      <Card className="overflow-hidden border-none shadow-xl hover:shadow-2xl transition-all duration-300 bg-white/80 backdrop-blur-sm group">
        <div className="relative aspect-[4/3] overflow-hidden bg-gradient-to-br from-gray-100 to-gray-200">
          {artwork.image_url ? (
            <img
              src={artwork.image_url}
              alt={artwork.title}
              className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                if (target.nextElementSibling) {
                  (target.nextElementSibling as HTMLElement).style.display = 'flex';
                }
              }}
            />
          ) : null}
          <div className="hidden w-full h-full items-center justify-center absolute inset-0">
            <Palette className="w-16 h-16 text-gray-300" />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>
        
        <CardContent className="p-6">
          <h3 className="text-xl text-gray-800 mb-3 line-clamp-2 group-hover:text-orange-600 transition-colors duration-300">
            {artwork.title || "Untitled"}
          </h3>
          
          <div className="space-y-2">
            {artwork.artist && (
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <User className="w-4 h-4 text-gray-400" />
                <span>{artwork.artist}</span>
              </div>
            )}
            
            {artwork.year && (
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Calendar className="w-4 h-4 text-gray-400" />
                <span>{artwork.year}</span>
              </div>
            )}
            
            {artwork.medium && (
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Palette className="w-4 h-4 text-gray-400" />
                <span className="line-clamp-1">{artwork.medium}</span>
              </div>
            )}
          </div>

          {artwork.description && (
            <p className="mt-4 text-sm text-gray-500 line-clamp-2">
              {artwork.description}
            </p>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
