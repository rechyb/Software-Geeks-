import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { createPageUrl } from "./utils";
import Layout from "./pages/Layout";
import Gallery from "./pages/Gallery";
import About from "./pages/About";

export default function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path={createPageUrl("Gallery")} element={<Gallery />} />
          <Route path={createPageUrl("About")} element={<About />} />
          <Route path="*" element={<Navigate to={createPageUrl("Gallery")} replace />} />
        </Routes>
      </Layout>
    </Router>
  );
}
