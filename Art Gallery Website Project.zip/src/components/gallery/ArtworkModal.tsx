import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, User, Calendar, Palette, Maximize2 } from "lucide-react";
import { Button } from "../ui/button";
import type { Artwork } from "../../api/dataverseClient";

interface ArtworkModalProps {
  artwork: Artwork | null;
  onClose: () => void;
}

export default function ArtworkModal({ artwork, onClose }: ArtworkModalProps) {
  const [imageZoomed, setImageZoomed] = React.useState(false);

  if (!artwork) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          transition={{ type: "spring", duration: 0.5 }}
          onClick={(e) => e.stopPropagation()}
          className="bg-white rounded-3xl shadow-2xl max-w-5xl w-full max-h-[90vh] overflow-hidden flex flex-col md:flex-row my-8"
        >
          {/* Image Section */}
          <div className="md:w-1/2 relative bg-gradient-to-br from-gray-100 to-gray-200">
            <div className="relative h-64 md:h-full flex items-center justify-center p-6">
              {artwork.image_url ? (
                <>
                  <img
                    src={artwork.image_url}
                    alt={artwork.title}
                    className={`w-full h-full object-contain transition-transform duration-300 ${
                      imageZoomed ? 'scale-150 cursor-zoom-out' : 'cursor-zoom-in'
                    }`}
                    onClick={() => setImageZoomed(!imageZoomed)}
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                      if (target.nextElementSibling) {
                        (target.nextElementSibling as HTMLElement).style.display = 'flex';
                      }
                    }}
                  />
                  <div className="hidden w-full h-full items-center justify-center absolute inset-0">
                    <Palette className="w-24 h-24 text-gray-300" />
                  </div>
                  <Button
                    variant="secondary"
                    size="icon"
                    className="absolute top-4 right-4 bg-white/80 backdrop-blur-sm hover:bg-white"
                    onClick={() => setImageZoomed(!imageZoomed)}
                  >
                    <Maximize2 className="w-4 h-4" />
                  </Button>
                </>
              ) : (
                <Palette className="w-24 h-24 text-gray-300" />
              )}
            </div>
          </div>

          {/* Content Section */}
          <div className="md:w-1/2 flex flex-col overflow-y-auto">
            <div className="p-8 flex-1">
              <div className="flex justify-between items-start mb-6">
                <h2 className="text-3xl text-gray-800 pr-4">
                  {artwork.title || "Untitled"}
                </h2>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="flex-shrink-0 hover:bg-gray-100"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <div className="space-y-4 mb-6">
                {artwork.artist && (
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
                      <User className="w-5 h-5 text-orange-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Artist</p>
                      <p className="text-lg text-gray-800">{artwork.artist}</p>
                    </div>
                  </div>
                )}

                {artwork.year && (
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center flex-shrink-0">
                      <Calendar className="w-5 h-5 text-rose-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Year</p>
                      <p className="text-lg text-gray-800">{artwork.year}</p>
                    </div>
                  </div>
                )}

                {artwork.medium && (
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                      <Palette className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Medium</p>
                      <p className="text-lg text-gray-800">{artwork.medium}</p>
                    </div>
                  </div>
                )}

                {artwork.dimensions && (
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                      <Maximize2 className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Dimensions</p>
                      <p className="text-lg text-gray-800">{artwork.dimensions}</p>
                    </div>
                  </div>
                )}
              </div>

              {artwork.description && (
                <div>
                  <h3 className="text-lg text-gray-800 mb-3">Description</h3>
                  <p className="text-gray-600 leading-relaxed">{artwork.description}</p>
                </div>
              )}
            </div>

            <div className="p-6 bg-gradient-to-r from-orange-50 to-rose-50 border-t border-gray-100">
              <p className="text-sm text-gray-600 text-center">
                From FGCU Dataverse Art Collection
              </p>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
