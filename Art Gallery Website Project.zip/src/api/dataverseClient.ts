// FGCU Dataverse API Client
const DATAVERSE_BASE_URL = 'https://dataverse.fgcu.edu';
const API_KEY = '849522d9-0aef-408e-9c93-6ae6adb4847d';
const SUBTREE = 'art';

export interface Artwork {
  id: string;
  title: string;
  artist: string;
  description: string;
  image_url: string;
  year: string;
  medium: string;
  dimensions?: string;
}

interface DataverseDataset {
  id: number;
  persistentUrl?: string;
  identifier?: string;
  storageIdentifier?: string;
  name?: string;
  title?: string;
  description?: string;
  published_at?: string;
  publicationDate?: string;
  createdAt?: string;
  contacts?: Array<{ name?: string }>;
  authors?: Array<{ name?: string }>;
  subjects?: string[];
  keywords?: Array<{ keywordValue?: string }>;
}

interface DataverseFile {
  dataFile?: {
    id: number;
    filename?: string;
    description?: string;
    contentType?: string;
  };
  label?: string;
  description?: string;
}

// Fetch all datasets from the art collection
export async function fetchArtworkDatasets(): Promise<Artwork[]> {
  try {
    const response = await fetch(`${DATAVERSE_BASE_URL}/api/dataverses/${SUBTREE}/contents`, {
      method: 'GET',
      headers: {
        'X-Dataverse-key': API_KEY,
      },
    });

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    if (data.status !== 'OK' || !data.data) {
      throw new Error('Invalid API response format');
    }

    // Filter for datasets only
    const datasets = data.data.filter((item: any) => item.type === 'dataset');
    
    // Fetch detailed information for each dataset
    const artworksPromises = datasets.map(async (dataset: any) => {
      try {
        return await fetchDatasetDetails(dataset.id);
      } catch (error) {
        console.error(`Error fetching dataset ${dataset.id}:`, error);
        return null;
      }
    });

    const artworksResults = await Promise.all(artworksPromises);
    const artworks = artworksResults.filter((artwork): artwork is Artwork => artwork !== null);
    
    return artworks;
  } catch (error) {
    console.error('Error fetching artworks:', error);
    throw error;
  }
}

// Fetch detailed metadata for a specific dataset
async function fetchDatasetDetails(datasetId: number): Promise<Artwork | null> {
  try {
    const response = await fetch(`${DATAVERSE_BASE_URL}/api/datasets/${datasetId}`, {
      method: 'GET',
      headers: {
        'X-Dataverse-key': API_KEY,
      },
    });

    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    
    if (data.status !== 'OK' || !data.data) {
      return null;
    }

    const dataset = data.data;
    const latestVersion = dataset.latestVersion;
    
    if (!latestVersion) {
      return null;
    }

    // Extract metadata fields
    const metadataBlocks = latestVersion.metadataBlocks;
    const citationFields = metadataBlocks?.citation?.fields || [];
    
    // Helper function to find field value
    const findField = (typeName: string) => {
      const field = citationFields.find((f: any) => f.typeName === typeName);
      if (!field) return '';
      
      if (field.typeClass === 'compound' && field.value) {
        // For compound fields like author
        return field.value.map((v: any) => 
          v.authorName?.value || v.name?.value || ''
        ).filter(Boolean).join(', ');
      } else if (field.typeClass === 'controlledVocabulary' && field.value) {
        return field.value.join(', ');
      } else {
        return field.value || '';
      }
    };

    const title = findField('title') || dataset.name || 'Untitled';
    const description = findField('dsDescription') || findField('description') || '';
    const author = findField('author') || findField('creator') || 'Unknown Artist';
    const subject = findField('subject') || '';
    const keyword = findField('keyword') || '';
    const productionDate = findField('productionDate') || findField('dateOfDeposit') || '';
    
    // Try to get publication date
    const publicationDate = dataset.publicationDate || latestVersion.releaseTime || productionDate;
    const year = publicationDate ? new Date(publicationDate).getFullYear().toString() : '';

    // Get the first file for image
    const files = latestVersion.files || [];
    let imageUrl = '';
    
    if (files.length > 0) {
      const imageFile = files.find((f: any) => 
        f.dataFile?.contentType?.startsWith('image/')
      ) || files[0];
      
      if (imageFile?.dataFile?.id) {
        // Use thumbnail for better performance
        imageUrl = `${DATAVERSE_BASE_URL}/api/access/datafile/${imageFile.dataFile.id}?imageThumb=400`;
      }
    }

    return {
      id: dataset.id.toString(),
      title,
      artist: author,
      description,
      image_url: imageUrl,
      year,
      medium: subject || keyword || 'Mixed Media',
      dimensions: undefined,
    };
  } catch (error) {
    console.error(`Error fetching dataset details for ${datasetId}:`, error);
    return null;
  }
}

// Search artworks by query
export function searchArtworks(artworks: Artwork[], query: string): Artwork[] {
  if (!query.trim()) {
    return artworks;
  }

  const searchTerm = query.toLowerCase();
  
  return artworks.filter(artwork => 
    artwork.title?.toLowerCase().includes(searchTerm) ||
    artwork.artist?.toLowerCase().includes(searchTerm) ||
    artwork.description?.toLowerCase().includes(searchTerm) ||
    artwork.medium?.toLowerCase().includes(searchTerm)
  );
}
